<?php
    
    include "../../config/db_connection.php";
    if(isset($_GET['nim'])){
        $id = $_GET['nim'];
        echo $nim;

        $sql = "DELETE  FROM mahasiswa WHERE NIM='$nim'";

        if ($conn->affected_rows > 0) {
            header("location:../admin_home_page.php?page=mahasiswa");
     } 
     else {
         header("location:../admin_home_page.php?page=mahasiswa&status=error");
     }
 }		
?>