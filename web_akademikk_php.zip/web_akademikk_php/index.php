<?php
    header("Location: mahasiswa");
    die();
    //DIBUAT OLEH BAYU ABDILLAH
?>
